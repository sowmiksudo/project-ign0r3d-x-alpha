<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\smsow\Documents\GitHub\alphasowmik-free-sms-sender\server\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>