<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="d-flex justify-content-center">
                <div class="card" style="max-width: 18rem;">
                    <div class="card-body">
                        <h5 class="card-title text-center"><?php echo e($user->name); ?></h5>
                        <h6 class="card-subtitle mb-2 text-muted text-center"><?php echo e($user->email); ?> | <?php echo e($user->number); ?>

                        </h6>
                        <?php if($user->is_verified): ?>
                        <p class="text-center text-info">VERIFIED</p>
                        <?php endif; ?>
                        <?php if($user->trashed()): ?>
                        <p class="text-center text-danger">BANNED</p>
                        <?php endif; ?>
                        <p class="card-text">
                        <div class="d-flex justify-content-center mb-2">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("demote")): ?>
                            <a href="/user/<?php echo e($user->id); ?>/promote" class="card-link"><button
                                    class="btn btn-sm btn-warning">PROMOTE</button></a>
                            <a href="/user/<?php echo e($user->id); ?>/demote" class="card-link"><button
                                    class="btn btn-sm btn-warning">DEMOTE</button></a>
                            <?php endif; ?>
                        </div>
                        <table class="table table-bordered">
                            <tbody>
                                <tr>
                                    <td>ROLE</td>
                                    <td><?php echo e(($user->getRoleNames()->first() === null) ? "User" :
                                        $user->getRoleNames()->first()); ?></td>
                                </tr>
                                <tr>
                                    <td>TOTAL SMS SENT</td>
                                    <td><?php echo e($user->messages->count()); ?></td>
                                </tr>
                                <tr>
                                    <td>TOTAL BOMBING</td>
                                    <td><?php echo e($user->bombings->count()); ?></td>
                                </tr>
                            </tbody>
                        </table>
                        </p>
                        <div class="d-flex justify-content-center">
                            <?php if(!$user->is_verified): ?>
                            <a href="/verify/<?php echo e($user->id); ?>" class="card-link"><button
                                    class="btn btn-sm btn-success">VERIFY</button></a>
                            <?php endif; ?>
                            <?php if(!$user->trashed()): ?>
                            <a href="/ban/<?php echo e($user->id); ?>" class="card-link"><button
                                    class="btn btn-sm btn-danger">BAN</button></a>
                            <?php else: ?>
                            <a href="/unban/<?php echo e($user->id); ?>" class="card-link"><button
                                    class="btn btn-sm btn-warning">UNBAN</button></a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user can edit')): ?>
                    <div class="d-flex justify-content-center">
                        <form method="POST" action="/user/<?php echo e($user->id); ?>/update"
                            class="d-flex justify-content-center flex-column">
                            <?php echo csrf_field(); ?>
                            <input type="text" class="form-control px-1 my-1" name="name" placeholder="Set new name"
                                value="<?php echo e($user->name); ?>">
                            <input type="number" class="form-control px-1 my-1" name="number"
                                placeholder="Set new number" value="<?php echo e($user->number); ?>">
                            <input type="email" class="form-control px-1 my-1" name="email" placeholder="Set new email"
                                value="<?php echo e($user->email); ?>">
                            <button class="mt-2 btn btn-danger btn-sm" type="submit">CHANGE INFO</button>
                        </form>
                    </div>
                    <hr>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user can changePass')): ?>
                    <div class="d-flex justify-content-center">
                        <form method="POST" action="/user/<?php echo e($user->id); ?>/newPass"
                            class="d-flex justify-content-center flex-column">
                            <?php echo csrf_field(); ?>
                            <input type="text" class="form-control px-1" name="password" placeholder="Set new password">
                            <button class="my-2 btn btn-danger btn-sm" type="submit">CHANGE PASS</button>
                        </form>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\smsow\Documents\GitHub\alphasowmik-free-sms-sender\server\resources\views/user.blade.php ENDPATH**/ ?>