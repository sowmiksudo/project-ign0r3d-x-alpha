<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="d-flex flex-row justify-content-between m-5">
                <div class="">
                    <form method="POST" action="/user/search">
                        <?php echo csrf_field(); ?>
                        <div class="mb-2">
                            <label for="email" class="form-label">Search by Email</label>
                            <input type="hidden" name="searchBy" value="email">
                            <input type="email" name="email" class="form-control" id="email"
                                aria-describedby="emailHelp" placeholder="someone@gmail.com">
                        </div>
                        <button type="submit" class="btn btn-primary mx-auto">SEARCH</button>
                    </form>
                </div>
                <div class="">
                    <form method="POST" action="/user/search">
                        <?php echo csrf_field(); ?>
                        <div class="mb-2">
                            <input type="hidden" name="searchBy" value="number">
                            <label for="number" class="form-label">Search by Number</label>
                            <input type="phone" name="number" class="form-control" id="number"
                                placeholder="01xxxxxxxxx">
                        </div>
                        <button type="submit" class="btn btn-primary mx-auto">SEARCH</button>
                    </form>
                </div>
            </div>

            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Email</th>
                        <th>Number</th>
                        <th>Created</th>
                        <th>Role</th>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user verify')): ?>
                        <th>VERIFY</th>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("user ban")): ?>
                        <th>UN|BAN</th>
                        <?php endif; ?>
                        <th>PROFILE</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->number); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($user->created_at)->isoFormat("LLLL")); ?></td>
                        <td><?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($loop->first ? '' : ', '); ?>

                            <span class="nice"><?php echo e($role); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user verify')): ?>
                        <?php if(!$user->is_verified): ?>
                        <td><a href="/verify/<?php echo e($user->id); ?>"><button class="btn btn-sm btn-primary">VERIFY</button></a>
                            <?php else: ?>
                        <td><button class="btn btn-sm btn-info">VERIFIED</button>
                        </td>
                        <?php endif; ?>
                        <?php endif; ?>

                        <?php if(!$user->trashed()): ?>
                        <td><a href="/ban/<?php echo e($user->id); ?>"><button class="btn btn-sm btn-primary">BAN</button></a></td>
                        <?php else: ?>
                        <td><a href="/unban/<?php echo e($user->id); ?>"><button class="btn btn-sm btn-warning">UNBAN</button></a>
                        </td>
                        <?php endif; ?>


                        <td><a href="/user/<?php echo e($user->id); ?>"><button class="btn btn-sm btn-primary">PROFILE</button></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="d-flex justify-content-center">
                <?php echo $users->links(); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\smsow\Documents\GitHub\alphasowmik-free-sms-sender\server\resources\views/users.blade.php ENDPATH**/ ?>