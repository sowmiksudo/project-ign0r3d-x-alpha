<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="d-flex flex-row justify-content-between m-5">
                <div class="">
                    <form method="POST" action="/user/search">
                        <?php echo csrf_field(); ?>
                        <div class="mb-2">
                            <label for="email" class="form-label">Search by Email</label>
                            <input type="hidden" name="searchBy" value="email">
                            <input type="email" name="email" class="form-control" id="email"
                                aria-describedby="emailHelp" placeholder="someone@gmail.com">
                        </div>
                        <button type="submit" class="btn btn-primary mx-auto">SEARCH</button>
                    </form>
                </div>
                <div class="">
                    <form method="POST" action="/user/search">
                        <?php echo csrf_field(); ?>
                        <div class="mb-2">
                            <input type="hidden" name="searchBy" value="number">
                            <label for="number" class="form-label">Search by Number</label>
                            <input type="phone" name="number" class="form-control" id="number"
                                placeholder="01xxxxxxxxx">
                        </div>
                        <button type="submit" class="btn btn-primary mx-auto">SEARCH</button>
                    </form>
                </div>
            </div>

            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Number</th>
                        <th>Amount</th>
                        <th>SenderName</th>
                        <th>SenderEmail</th>
                        <th>SenderNumber</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $bombings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bombing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($bombing->id); ?></td>
                        <td><?php echo e($bombing->number); ?></td>
                        <td><?php echo e($bombing->amount); ?></td>
                        <td><?php echo e($bombing->user->name); ?></td>
                        <td><?php echo e($bombing->user->email); ?></td>
                        <td><?php echo e($bombing->user->number); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($bombing->created_at)->isoFormat("LLLL")); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="d-flex justify-content-center">
                <?php echo $bombings->links(); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\smsow\Documents\GitHub\alphasowmik-free-sms-sender\server\resources\views/bombings.blade.php ENDPATH**/ ?>