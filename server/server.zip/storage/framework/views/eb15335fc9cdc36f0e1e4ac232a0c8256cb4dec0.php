<?php echo e($slot); ?>

<?php /**PATH C:\Users\smsow\Documents\GitHub\alphasowmik-free-sms-sender\server\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>