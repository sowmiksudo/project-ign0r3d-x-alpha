<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
    //
    protected $user;

    public function __construct()
    {
        $this->middleware("auth:api", ["except" => ["login", "register" ]]);
        $this->user = new User;
    }

    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string',
            'email' => 'required|email|unique:users',
            'number'=>'required|numeric|digits:11|unique:users',
            'password' => 'required|min:6|confirmed',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => $validator->messages()->toArray()
            ], 200);
        }
        $data = [
            "name" => $request->name,
            "email" => $request->email,
            "number" => $request->number,
            "password" => Hash::make($request->password)
        ];
        // dd($data);
        $user = User::create($data);
        $user->assignRole("User");
        $responseMessage = "Registration Successful, login to continue.";
        return response()->json([
            'success' => true,
            'message' => $responseMessage
        ], 200);
    }
    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|string',
            'password' => 'required|min:6',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => $validator->messages()->toArray()
            ], 200);
        }
        $credentials = $request->only(["email", "password"]);
        $user = User::withTrashed()->where('email', $credentials['email'])->first();
        if ($user) {
            if (!auth()->attempt($credentials)) {
                if($user->trashed()){
                    return response()->json([
                        "success"=>false,
                        "message"=>"You have been banned for violating usage."
                    ]);
                }

                $responseMessage = "Invalid username or password";
                return response()->json([
                    "success" => false,
                    "message" => $responseMessage
                ], 200);
            }
            $accessToken = auth()->user()->createToken('authToken')->accessToken;
            $responseMessage = "Login Successful";
            return $this->respondWithToken($accessToken, $responseMessage, auth()->user());
        } else {
            $responseMessage = "Sorry, this user does not exist";
            return response()->json([
                "success" => false,
                "message" => $responseMessage,
            ], 200);
        }
    }
    public function viewProfile()
    {
        $responseMessage = "User profile";
        $data = Auth::guard("api")->user();
        return response()->json([
            "success" => true,
            "message" => $responseMessage,
            "data" => $data
        ], 200);
    }
    public function logout()
    {
        $user = Auth::guard("api")->user()->token();
        $user->revoke();
        $responseMessage = "Successfully logged out";
        return response()->json([
            'success' => false,
            'message' => $responseMessage
        ], 200);
    }

    public function saveName(Request $request){
        $validator = Validator::make($request->all(), [
            "name"=>"required"
        ]);

        if($validator->fails()){
            return [
                "success"=>false,
                "message"=>$validator->messages()->toArray()
            ];
        }

        $id = Auth::guard("api")->user()->id;

        $user = User::find($id);

        $user->name = $request->name;

        $saved = $user->save();

        if($saved){

            $user = User::find($id);

            return [
                "success"=>true,
                "message"=>"Profile updated successfully.",
                "data"=>$user
            ];
        }

    }

    public function change(Request $request){
        $validator = Validator::make($request->all(), [
            "old_pass"=>"required",
            "new_pass"=>"required|min:6"
        ]);
        if($validator->fails()){
            return [
                'success'=>false,
                "message"=>$validator->messages()->toArray()
            ];
        }

        $user = User::find(auth()->user()->id);
        if(!Hash::check($request->old_pass, $user->password)){
            return [
                "success"=>false,
                "message"=>"Invalid password."
            ];
        }
        $user->update(["password"=>Hash::make($request->new_pass)]);
        return [
            "success"=>true,
            "message"=>"Password changed successfully."
        ];
    }
}

